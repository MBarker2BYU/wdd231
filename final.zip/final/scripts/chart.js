const canvas = document.getElementById('trajectory-chart');
const ctx = canvas.getContext('2d');
const resultsTableBody = document.getElementById('resultsTableBody');

// Resolve CSS variables from :root
const rootStyles = getComputedStyle(document.documentElement);
const colors = {
    background: rootStyles.getPropertyValue('--osu-gray').trim(),  // #666666
    border: rootStyles.getPropertyValue('--osu-black').trim(),    // #000000
    grid: rootStyles.getPropertyValue('--osu-white').trim(),      // #FFFFFF
    axes: rootStyles.getPropertyValue('--osu-white').trim(),  // #FFFFFF 
    trajectory: rootStyles.getPropertyValue('--osu-scarlet').trim(), // #BB0000
    labels: rootStyles.getPropertyValue('--osu-black').trim() // #000000
};

// Set canvas dimensions based on container
function resizeCanvas() {
    canvas.width = canvas.offsetWidth;
    canvas.height = 300;
    drawChart([], colors); // Pass colors
}

window.addEventListener('resize', resizeCanvas);
resizeCanvas();

function drawChart(trajectoryData, colors) {
    const width = canvas.width;
    const height = canvas.height;
    const padding = 60;

    // Clear the canvas
    ctx.clearRect(0, 0, width, height);

    // Fill the chart background
    ctx.fillStyle = colors.background;
    ctx.fillRect(padding, padding, width - 2 * padding, height - 2 * padding);    

    // Always draw the chart structure (axes, grid, labels)
    const maxDistance = trajectoryData.length > 0 ? Math.max(...trajectoryData.map(d => d.distance)) : 500;
    const maxDrop = trajectoryData.length > 0 ? Math.max(...trajectoryData.map(d => Math.abs(d.drop))) : 50;
    const minDrop = trajectoryData.length > 0 ? Math.min(...trajectoryData.map(d => d.drop)) : -50;

    const xScale = (width - 2 * padding) / maxDistance;
    const yScale = (height - 2 * padding) / (maxDrop - minDrop);

    // Draw grid lines
    ctx.beginPath();
    ctx.strokeStyle = colors.grid;
    ctx.lineWidth = 1;
    ctx.setLineDash([5, 5]);

    for (let i = 100; i <= maxDistance; i += 100) {
        const x = padding + i * xScale;
        ctx.moveTo(x, padding);
        ctx.lineTo(x, height - padding);
    }

    const dropStep = (maxDrop - minDrop) / 4;
    for (let i = minDrop; i <= maxDrop; i += dropStep) {
        const y = height - padding - (i - minDrop) * yScale;
        ctx.moveTo(padding, y);
        ctx.lineTo(width - padding, y);
    }
    ctx.stroke();
    ctx.setLineDash([]);

    // Draw axes
    ctx.beginPath();
    ctx.strokeStyle = colors.axes;
    ctx.lineWidth = 1;

    ctx.moveTo(padding, height - padding);
    ctx.lineTo(width - padding, height - padding);
    ctx.moveTo(padding, padding);
    ctx.lineTo(padding, height - padding);
    ctx.stroke();

    // Draw axis labels
    ctx.font = '14px "Allerta Stencil", Arial, serif';
    ctx.fillStyle = colors.labels;

    ctx.textAlign = 'center';
    ctx.fillText('Distance (yards)', width / 2, height - 10);

    ctx.save();
    ctx.translate(padding - 40, height / 2);
    ctx.rotate(-Math.PI / 2);
    ctx.textAlign = 'center';
    ctx.fillText('Drop (inches)', 0, 0);
    ctx.restore();

    for (let i = 0; i <= maxDistance; i += 100) {
        const x = padding + i * xScale;
        ctx.fillText(i, x, height - padding + 20);
    }

    const dropStepLabel = (maxDrop - minDrop) / 4;
    ctx.textAlign = 'right';
    for (let i = minDrop; i <= maxDrop; i += dropStepLabel) {
        const y = height - padding - (i - minDrop) * yScale;
        ctx.fillText(Math.round(i), padding - 10, y + 5);
    }

    // Draw trajectory line
    if (trajectoryData && trajectoryData.length > 0) {
        ctx.beginPath();
        ctx.strokeStyle = colors.trajectory;
        ctx.lineWidth = 2;
        trajectoryData.forEach((point, index) => {
            const x = padding + point.distance * xScale;
            const y = height - padding - (point.drop - minDrop) * yScale;
            if (index === 0) {
                ctx.moveTo(x, y);
            } else {
                ctx.lineTo(x, y);
            }
        });
        ctx.stroke();
    }

    // Draw a border around the chart area at the end
    ctx.strokeStyle = colors.border;
    ctx.lineWidth = 2;
    ctx.strokeRect(padding, padding, width - 2 * padding, height - 2 * padding);
}

function updateChartFromTable() {
    const rows = resultsTableBody.getElementsByTagName('tr');
    const chartData = [];
    for (let row of rows) {
        const cells = row.getElementsByTagName('td');
        if (cells.length >= 5) {
            const distance = parseFloat(cells[0].textContent);
            const drop = parseFloat(cells[3].textContent);
            if (!isNaN(distance) && !isNaN(drop)) {
                chartData.push({ distance, drop: -Math.abs(drop) });
            }
        }
    }
    if (chartData.length > 0) {
        drawChart(chartData, colors);
    } else {
        drawChart([], colors);
    }
}

const observer = new MutationObserver((mutations) => {
    mutations.forEach(() => {
        setTimeout(updateChartFromTable, 100);
    });
});

observer.observe(resultsTableBody, { childList: true, subtree: true });