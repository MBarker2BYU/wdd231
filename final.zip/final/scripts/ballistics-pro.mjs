import { fetchData } from './fetch-data.mjs';
import { calculateTrajectory } from './ballistics.mjs';

document.addEventListener('DOMContentLoaded', () => 
    {
        fetchData('data/ammunition.json').then(data => 
        {
            const tbody = document.querySelector('#ammoTable tbody');
            data.forEach(item => {
              const row = document.createElement('tr');
              row.innerHTML = `
                <td>${item.name}</td>
                <td>${item.muzzleVelocity}</td>
                <td>${item.ballisticCoefficient}</td>
                <td>${item.bulletWeight}</td>
              `;
              tbody.appendChild(row);
            });
        });

        // Function to Display Calculator Results
          const displayResults = (results) => {
            const tbody = document.querySelector('#resultsTableBody tbody');
            tbody.innerHTML = ''; // Clear previous results
            results.forEach(result => {
              const row = document.createElement('tr');
              row.innerHTML = `
                <td>${result.distance}</td>
                <td>${result.velocity}</td>
                <td>${result.energy}</td>
                <td>${result.drop}</td>
                <td>${result.windDrift}</td>
              `;
              tbody.appendChild(row);
            });
          };
        
          // Setup Calculator with Callback
          setupCalculator(displayResults);
        
        
          // Display Last Calculation Results (if any)
          const savedResults = localStorage.getItem('calculationResults');
          if (savedResults) {
            displayResults(JSON.parse(savedResults));
          }
        
          // Local Storage for Preferences (e.g., last selected ammo)
          const savedAmmo = localStorage.getItem('selectedAmmo');
          if (savedAmmo) {
            console.log('Last selected ammo:', savedAmmo);
          }         

    });

function setupCalculator(displayResultsCallback) {
    const form = document.getElementById('calcForm');

    form.addEventListener('submit', (e) => {
        e.preventDefault();
        const formData = new FormData(form);
        const inputs = {
            muzzleVelocity: parseFloat(formData.get('muzzleVelocity')),
            ballisticCoefficient: parseFloat(formData.get('ballisticCoefficient')),
            bulletWeight: parseFloat(formData.get('bulletWeight')),
            windSpeed: parseFloat(formData.get('windSpeed'))
        };

        // Validate inputs
        if (isNaN(inputs.muzzleVelocity) || isNaN(inputs.ballisticCoefficient) ||
            isNaN(inputs.bulletWeight) || isNaN(inputs.windSpeed)) {
            alert('Please enter valid numbers for all fields.');
            return;
        }

        // Calculate trajectory
        const results = calculateTrajectory(inputs);

        // Store the last calculation in localStorage
        localStorage.setItem('lastCalculation', JSON.stringify(inputs));
        localStorage.setItem('calculationResults', JSON.stringify(results));

        // Call the callback to display results
        if (displayResultsCallback) {
            displayResultsCallback(results);
        }
    });
}