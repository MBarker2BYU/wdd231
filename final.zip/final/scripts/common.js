const today = new Date();
const currentyear = document.getElementById("currentyear");
const lastmodified = document.getElementById("lastmodified");

currentyear.textContent = "\u00A9" + today.getFullYear();
lastmodified.textContent = document.lastModified;

document.addEventListener('DOMContentLoaded', () => {
  // Navigation Toggle for Mobile
  const hamburger = document.querySelector('.hamburger');
  const navMenu = document.querySelector('nav ul');
  
  hamburger.addEventListener('click', () => 
    {
      hamburger.classList.toggle('active');
      navMenu.classList.toggle('active');
    });
  

  // Mode Toggle Logic (runs on all pages)
    const modeToggle = document.getElementById('modeToggle');
    const htmlElement = document.documentElement;

    // Load saved theme from localStorage
    const savedTheme = localStorage.getItem('theme') || 'light';
    htmlElement.setAttribute('data-theme', savedTheme);
    modeToggle.textContent = savedTheme === 'light' ? 'Dark Mode' : 'Light Mode';

    // Toggle theme on button click
    if (modeToggle) {
        modeToggle.addEventListener('click', () => {
            const currentTheme = htmlElement.getAttribute('data-theme');
            const newTheme = currentTheme === 'light' ? 'dark' : 'light';
            htmlElement.setAttribute('data-theme', newTheme);
            localStorage.setItem('theme', newTheme);
            modeToggle.textContent = newTheme === 'light' ? 'Dark Mode' : 'Light Mode';

            // Force redraw by toggling a class and triggering reflow
            modeToggle.classList.remove('theme-redraw');
            void modeToggle.offsetWidth; // Trigger reflow
            modeToggle.classList.add('theme-redraw');
        });
    }
  });